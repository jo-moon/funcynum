# funcynum
This library was created to store recursive and sorting functions

## building this package locally
`python setup.py sdist`

## installing this package from github
`pip install git+https://github.com/jo-moon/funcynum.git`

## updating this package from github
`pip install --upgrade git+https://github.com/jo-moon/funcynum.git`
